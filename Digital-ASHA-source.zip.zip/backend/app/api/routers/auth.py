from typing import List, Optional
from datetime import date
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from backend.app.db.database import get_db
from backend.app.core.security import (
    verify_password,
    get_password_hash,
    create_access_token,
    create_password_reset_token,
    verify_password_reset_token
)
from backend.app.models.models import User, Village, Parent, AshaWorker, Family, AuditLog
from backend.app.schemas.schemas import (
    UserCreate,
    ParentRegistration,
    UserLogin,
    Token,
    UserResponse,
    VillageResponse,
    ForgotPasswordRequest,
    ResetPasswordConfirm,
    ChangePasswordRequest
)
from backend.app.api.deps import get_current_user

router = APIRouter(prefix="/auth", tags=["Authentication & Password Recovery"])

@router.post("/register", response_model=Token, status_code=status.HTTP_201_CREATED)
def register_parent(user_in: ParentRegistration, db: Session = Depends(get_db)):
    """
    Public self-registration flow for Parents using mobile number/email and password.
    Automatically establishes User, Parent, and Family records.
    """
    # Check if username or phone already exists
    existing_user = db.query(User).filter(
        (User.username == user_in.username) | (User.phone == user_in.phone)
    ).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username or mobile phone number is already registered in the system."
        )

    # Validate village
    village = db.query(Village).filter(Village.id == user_in.village_id).first()
    if not village:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Selected village does not exist."
        )

    hashed_pw = get_password_hash(user_in.password)
    new_user = User(
        username=user_in.username,
        phone=user_in.phone,
        full_name=user_in.full_name,
        email=user_in.email,
        password_hash=hashed_pw,
        role="parent",
        is_active=True
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    # Create Parent Profile
    p_profile = Parent(
        user_id=new_user.id,
        alternate_phone=user_in.alternate_phone,
        occupation=user_in.occupation
    )
    db.add(p_profile)
    db.commit()
    db.refresh(p_profile)

    # Create Family Record
    fam = Family(
        parent_id=p_profile.id,
        village_id=village.id,
        family_head_name=new_user.full_name,
        house_number=user_in.address or "1",
        address=user_in.address or village.name,
        contact_number=new_user.phone
    )
    db.add(fam)
    
    # Audit log
    audit = AuditLog(
        user_id=new_user.id,
        action="PARENT_REGISTERED",
        entity_type="User",
        entity_id=new_user.id,
        details=f"Parent {new_user.full_name} registered in village {village.name}"
    )
    db.add(audit)
    db.commit()

    token_payload = {
        "sub": str(new_user.id),
        "username": new_user.username,
        "role": new_user.role,
        "full_name": new_user.full_name
    }
    access_token = create_access_token(token_payload)

    return Token(
        access_token=access_token,
        token_type="bearer",
        user_id=new_user.id,
        username=new_user.username,
        full_name=new_user.full_name,
        role=new_user.role,
        village_id=village.id,
        village_name=village.name
    )

@router.post("/login", response_model=Token)
def login(login_data: UserLogin, db: Session = Depends(get_db)):
    """
    Authenticates user and returns JWT token with role context and village jurisdiction.
    """
    user = db.query(User).filter(
        (User.username == login_data.username) | (User.phone == login_data.username)
    ).first()

    if not user or not verify_password(login_data.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username/mobile number or password."
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is deactivated. Please contact your Primary Health Centre administrator."
        )

    village_id = None
    village_name = None

    if user.role == "parent" and user.parent_profile and user.parent_profile.families:
        fam = user.parent_profile.families[0]
        village_id = fam.village_id
        village_name = fam.village.name if fam.village else None
    elif user.role == "asha" and user.asha_profile and user.asha_profile.assigned_village:
        village_id = user.asha_profile.assigned_village_id
        village_name = user.asha_profile.assigned_village.name

    token_payload = {
        "sub": str(user.id),
        "username": user.username,
        "role": user.role,
        "full_name": user.full_name
    }
    access_token = create_access_token(token_payload)

    return Token(
        access_token=access_token,
        token_type="bearer",
        user_id=user.id,
        username=user.username,
        full_name=user.full_name,
        role=user.role,
        village_id=village_id,
        village_name=village_name
    )

@router.get("/me", response_model=UserResponse)
def get_current_user_profile(current_user: User = Depends(get_current_user)):
    """
    Fetches the authenticated user profile with village and worker code details.
    """
    village_id = None
    village_name = None
    worker_code = None

    if current_user.role == "parent" and current_user.parent_profile and current_user.parent_profile.families:
        fam = current_user.parent_profile.families[0]
        village_id = fam.village_id
        village_name = fam.village.name if fam.village else None
    elif current_user.role == "asha" and current_user.asha_profile:
        worker_code = current_user.asha_profile.worker_code
        if current_user.asha_profile.assigned_village:
            village_id = current_user.asha_profile.assigned_village_id
            village_name = current_user.asha_profile.assigned_village.name

    return UserResponse(
        id=current_user.id,
        username=current_user.username,
        phone=current_user.phone,
        full_name=current_user.full_name,
        email=current_user.email,
        role=current_user.role,
        is_active=current_user.is_active,
        created_at=current_user.created_at,
        updated_at=current_user.updated_at,
        village_id=village_id,
        village_name=village_name,
        worker_code=worker_code
    )

@router.post("/forgot-password")
def forgot_password(req: ForgotPasswordRequest, db: Session = Depends(get_db)):
    """
    Password reset initiation. Generates a secure reset token for recovery.
    """
    user = db.query(User).filter(
        (User.username == req.username_or_phone) | (User.phone == req.username_or_phone)
    ).first()

    if not user:
        # Avoid user enumeration in production, but provide clean message
        return {
            "message": "If an account matches the provided mobile/username, password reset instructions have been generated.",
            "reset_token": None
        }

    reset_token = create_password_reset_token(user.id, user.username)

    # In development/demo, return reset token directly for seamless testing
    return {
        "message": f"Password reset token generated successfully for {user.full_name}.",
        "reset_token": reset_token,
        "username": user.username,
        "phone": user.phone
    }

@router.post("/reset-password")
def reset_password(req: ResetPasswordConfirm, db: Session = Depends(get_db)):
    """
    Completes password reset using verified reset token.
    """
    payload = verify_password_reset_token(req.token)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid or expired password reset token."
        )

    user_id = int(payload.get("sub"))
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found.")

    user.password_hash = get_password_hash(req.new_password)
    
    # Audit log
    audit = AuditLog(
        user_id=user.id,
        action="PASSWORD_RESET",
        entity_type="User",
        entity_id=user.id,
        details=f"Password reset completed for user {user.username}"
    )
    db.add(audit)
    db.commit()

    return {"message": "Password has been successfully updated. You may now log in with your new password."}

@router.post("/change-password")
def change_password(
    req: ChangePasswordRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Authenticated password change requiring current password verification.
    """
    if not verify_password(req.current_password, current_user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Current password is incorrect."
        )

    current_user.password_hash = get_password_hash(req.new_password)
    
    audit = AuditLog(
        user_id=current_user.id,
        action="PASSWORD_CHANGED",
        entity_type="User",
        entity_id=current_user.id,
        details=f"User {current_user.username} updated password."
    )
    db.add(audit)
    db.commit()

    return {"message": "Password changed successfully."}

@router.get("/villages", response_model=List[VillageResponse])
def list_available_villages(db: Session = Depends(get_db)):
    """
    Returns list of villages for dropdowns and registrations.
    """
    villages = db.query(Village).order_by(Village.name).all()
    results = []
    for v in villages:
        asha_name = v.asha_workers[0].user.full_name if v.asha_workers and v.asha_workers[0].user else "Unassigned"
        results.append(VillageResponse(
            id=v.id,
            name=v.name,
            sub_center=v.sub_center,
            phc_name=v.phc_name,
            district=v.district,
            state=v.state,
            pin_code=v.pin_code,
            population=v.population,
            asha_worker_id=v.asha_workers[0].id if v.asha_workers else None,
            asha_worker_name=asha_name,
            created_at=v.created_at,
            total_children=len(v.children)
        ))
    return results

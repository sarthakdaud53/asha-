/**
 * Digital ASHA - Health Administration Controller
 */

let adminVillages = [];
let ashaWorkers = [];
let allVaccines = [];

document.addEventListener('DOMContentLoaded', async () => {
  const user = Auth.checkSession(['admin']);
  if (!user) return;

  await loadAdminDashboard();
  await loadVillagesTable();
  await loadAshaWorkersList();
  await loadVaccineMasterList();
  setupAdminEventListeners();
});

async function loadAdminDashboard() {
  try {
    const stats = await API.getAdminDashboard();
    document.getElementById('stat-total-villages').textContent = stats.total_villages;
    document.getElementById('stat-total-ashas').textContent = stats.total_asha_workers;
    document.getElementById('stat-total-children').textContent = stats.total_children;
    document.getElementById('stat-total-administered').textContent = stats.total_vaccines_administered;
    document.getElementById('stat-total-overdue').textContent = stats.total_overdue_cases;
    document.getElementById('stat-overall-rate').textContent = `${stats.overall_immunization_rate}%`;

    // Render Village Coverage Table
    const vTable = document.getElementById('village-coverage-tbody');
    if (vTable && stats.villages_coverage) {
      vTable.innerHTML = stats.villages_coverage.map(v => `
        <tr class="border-b border-slate-100 hover:bg-slate-50 text-sm">
          <td class="py-3 px-4 font-bold text-slate-800">${v.village_name}</td>
          <td class="py-3 px-4 text-slate-600">${v.sub_center}</td>
          <td class="py-3 px-4 text-slate-600">
            <div>${v.asha_name}</div>
            <div class="text-xs text-slate-400 font-mono">${v.asha_phone}</div>
          </td>
          <td class="py-3 px-4 font-semibold text-slate-700">${v.total_children}</td>
          <td class="py-3 px-4 text-emerald-700 font-bold">${v.fully_immunized}</td>
          <td class="py-3 px-4 text-rose-700 font-bold">${v.overdue_cases}</td>
          <td class="py-3 px-4">
            <div class="flex items-center space-x-2">
              <div class="w-16 bg-slate-200 rounded-full h-2">
                <div class="bg-teal-600 h-2 rounded-full" style="width: ${v.coverage_rate}%"></div>
              </div>
              <span class="text-xs font-bold text-slate-800">${v.coverage_rate}%</span>
            </div>
          </td>
        </tr>
      `).join('');
    }
  } catch (err) {
    Utils.showToast(err.message, 'error');
  }
}

async function loadVillagesTable() {
  const tbody = document.getElementById('admin-villages-tbody');
  if (!tbody) return;

  try {
    adminVillages = await API.getAdminVillages();
    tbody.innerHTML = adminVillages.map(v => `
      <tr class="border-b border-slate-100 hover:bg-slate-50 text-sm">
        <td class="py-3 px-4 font-bold text-slate-800">${v.name}</td>
        <td class="py-3 px-4 text-slate-600">${v.sub_center}</td>
        <td class="py-3 px-4 text-slate-600">${v.phc_name}</td>
        <td class="py-3 px-4 text-slate-600">${v.district}, ${v.state}</td>
        <td class="py-3 px-4">
          ${v.asha_worker_name 
            ? `<span class="px-2.5 py-1 rounded-lg text-xs font-bold bg-teal-50 text-teal-800 border border-teal-200">👩‍⚕️ ${v.asha_worker_name}</span>`
            : `<span class="px-2.5 py-1 rounded-lg text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">⚠️ Unassigned</span>`
          }
        </td>
        <td class="py-3 px-4 font-semibold text-slate-700">${v.total_children}</td>
        <td class="py-3 px-4 text-right">
          <button 
            onclick="openAssignAshaModal(${v.id}, '${v.name.replace(/'/g, "\\'")}')" 
            class="px-2.5 py-1.5 rounded-lg text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300">
            Assign ASHA
          </button>
        </td>
      </tr>
    `).join('');
  } catch (err) {
    console.error('Failed to load admin villages', err);
  }
}

async function loadAshaWorkersList() {
  try {
    ashaWorkers = await API.getAshaWorkers();
    const select = document.getElementById('assign-asha-select');
    if (select) {
      select.innerHTML = '<option value="">-- Select ASHA Worker --</option>' +
        ashaWorkers.map(a => `<option value="${a.id}">${a.full_name} (${a.phone})</option>`).join('');
    }
  } catch (err) {
    console.error('Failed to load ASHA workers', err);
  }
}

async function loadVaccineMasterList() {
  const tbody = document.getElementById('admin-vaccines-tbody');
  if (!tbody) return;

  try {
    allVaccines = await API.getVaccines();
    tbody.innerHTML = allVaccines.map(v => `
      <tr class="border-b border-slate-100 hover:bg-slate-50 text-sm">
        <td class="py-3 px-4 font-mono font-bold text-teal-800">${v.code}</td>
        <td class="py-3 px-4 font-bold text-slate-800">${v.name}</td>
        <td class="py-3 px-4 text-slate-600">${v.category}</td>
        <td class="py-3 px-4 text-slate-600">${v.target_age_label} (${v.target_age_days}d)</td>
        <td class="py-3 px-4 text-slate-600">${v.dose_amount} • ${v.route}</td>
        <td class="py-3 px-4 text-xs text-slate-500 max-w-xs truncate" title="${v.prevents_diseases}">${v.prevents_diseases}</td>
      </tr>
    `).join('');
  } catch (err) {
    console.error('Failed to load vaccines', err);
  }
}

// ----------------- Assign ASHA Modal -----------------
let activeAssignVillageId = null;
function openAssignAshaModal(villageId, villageName) {
  activeAssignVillageId = villageId;
  const modal = document.getElementById('assign-asha-modal');
  modal.classList.remove('hidden');
  document.getElementById('assign-village-name').textContent = villageName;
}

function closeAssignAshaModal() {
  document.getElementById('assign-asha-modal').classList.add('hidden');
}

// ----------------- Create Village Modal -----------------
function openCreateVillageModal() {
  document.getElementById('create-village-modal').classList.remove('hidden');
}

function closeCreateVillageModal() {
  document.getElementById('create-village-modal').classList.add('hidden');
}

function setupAdminEventListeners() {
  // Create village form
  const vForm = document.getElementById('create-village-form');
  if (vForm) {
    vForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const payload = {
        name: document.getElementById('new-village-name').value,
        sub_center: document.getElementById('new-village-subcenter').value,
        phc_name: document.getElementById('new-village-phc').value,
        district: document.getElementById('new-village-district').value,
        state: document.getElementById('new-village-state').value || 'Madhya Pradesh',
        pin_code: document.getElementById('new-village-pincode').value || null
      };

      try {
        await API.createVillage(payload);
        Utils.showToast('Village created successfully!', 'success');
        closeCreateVillageModal();
        vForm.reset();
        await loadAdminDashboard();
        await loadVillagesTable();
      } catch (err) {
        Utils.showToast(err.message, 'error');
      }
    });
  }

  // Assign ASHA form
  const assignForm = document.getElementById('assign-asha-form');
  if (assignForm) {
    assignForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const ashaId = document.getElementById('assign-asha-select').value;
      if (!ashaId || !activeAssignVillageId) {
        Utils.showToast('Please select an ASHA worker', 'warning');
        return;
      }

      try {
        await API.assignAshaToVillage(activeAssignVillageId, parseInt(ashaId));
        Utils.showToast('ASHA worker assigned successfully!', 'success');
        closeAssignAshaModal();
        await loadAdminDashboard();
        await loadVillagesTable();
      } catch (err) {
        Utils.showToast(err.message, 'error');
      }
    });
  }
}
